package com.example.travelsagency.utilities;

public class AgencieUtilities {
    public static final String ID_AGENCIE = "id";
    public static final String ID_USER = "user_id_fk";
    public static final String NAME_AGENCIE = "name";
    public static final String LOCATION_AGENCIE = "location";
    public static final String DESCRIPTION_AGENCIE = "description";
    public static final String BUSSINES_NAME = "bussines_name";
    public static final String RATING = "rating";
}
