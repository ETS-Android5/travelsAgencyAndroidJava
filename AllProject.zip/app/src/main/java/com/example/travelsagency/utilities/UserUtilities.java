package com.example.travelsagency.utilities;

public class UserUtilities {
    public static final String ID_FIELD = "id";
    public static final String NAME_FIELD = "name";
    public static final String EMAIL_FIELD = "email";
    public static final String PASSWORD_FIELD = "password";
    public static final String TELEPHONE_FIELD = "telephone";
    public static final String ROLE_FIELD = "role";
    public static final String RFC_FIELD = "rfc";
    public static final String CREATED_AT = "created_at";
}
